# multiple-website
host multiple websites under /public directory and static serve them dynamically using nodejs app
